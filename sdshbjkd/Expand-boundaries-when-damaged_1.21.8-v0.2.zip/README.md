# Expand boundaries when damaged

受到伤害才会扩大边界

数据包仅1.21.8可用。

建议使用极限模式游玩。

**加载自动初始化，重载不重置进度**。

如需 **重置进度** 或 **更换边界中心** 请使用以下指令重新触发初始化：

```text
/function hdk:ini
```
